08-08-2024	1.0.0.0		[Parita]	First release.

						